# servicios/admin.py
from django.contrib import admin
from .models import EspecialidadMedica

admin.site.register(EspecialidadMedica)